package com.company;

public class Motorcycle extends Vehicle{
    public Motorcycle(String name, int weight, int price, int seatingCapacity, int kmPerLiter, String fuelType) {
        super(name, weight, price, seatingCapacity, kmPerLiter, fuelType);
    }

}
