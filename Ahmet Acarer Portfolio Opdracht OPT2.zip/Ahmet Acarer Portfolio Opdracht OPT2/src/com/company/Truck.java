package com.company;

public class Truck extends Vehicle{
    public Truck(String name, int weight, int price, int seatingCapacity, int kmPerLiter, String fuelType) {
        super(name, weight, price, seatingCapacity, kmPerLiter, fuelType);
    }
}
